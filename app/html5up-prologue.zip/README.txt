Prologue 1.2 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Prologue, a simple, single page responsive site template. It features a
clean, minimalistic design and a sticky sidebar with navigation-linked scrolling.
	
Demo images* are courtesy of the ridiculously talented Felicia Simion. Check out
more of her amazing work over at deviantART:

http://ineedchemicalx.deviantart.com/

* Not included with this download (replaced with generic placeholder images).
I only have permission to use her work in my own onsite demos so do NOT download
or use any of her photos without her explicit permission.


AJ
n33.co @n33co dribbble.com/n33


Credits

	Images (Demo Only)
		Felicia Simion (http://ineedchemicalx.deviantart.com/)
		
	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)

	Other
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		CSS3 Pie (css3pie.com)
		skelJS (skelJS.org)